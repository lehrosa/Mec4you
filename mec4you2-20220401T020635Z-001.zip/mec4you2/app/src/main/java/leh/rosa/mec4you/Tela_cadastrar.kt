package leh.rosa.mec4you

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton

class Tela_cadastrar : AppCompatActivity() {
    private lateinit var Btcadastrar: ImageButton
    private lateinit var Btlimpar: ImageButton
    private lateinit var Edusuario: EditText
    private lateinit var Edemail: EditText
    private lateinit var Edsenha: EditText
    private lateinit var Edresenha: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_cadastrar)
        buscar()
        botoes()

    }



    fun buscar() {
        Edusuario = findViewById(R.id.Edusuario)
        Edemail = findViewById(R.id.Edemail)
        Edsenha = findViewById(R.id.Edsenha)
        Edresenha = findViewById(R.id.Edresenha)
        Btcadastrar = findViewById(R.id.Btcadastrar)
        Btlimpar = findViewById(R.id.Btlimpar)
    }

    fun botoes() {
        Btcadastrar.setOnClickListener() {
            startActivity(Intent(baseContext, Tela_home::class.java))

        }
        Btlimpar.setOnClickListener() {
            Edusuario.setText("")
            Edemail.setText("")
            Edsenha.setText("")
            Edresenha.setText("")
        }


    }

}