package leh.rosa.mec4you

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class Tela_home : AppCompatActivity() {
    private lateinit var Btvoltar: ImageButton
    private lateinit var Btwpp: ImageButton
    private lateinit var Btcamisetas: ImageButton
    private lateinit var Btmoletom: ImageButton
    private lateinit var Bttenis: ImageButton
    private lateinit var Bttenis22: ImageButton
    var carregar: ActivityResultLauncher<Array<String>>?= null
    private var wb = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_home)

        carregar = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions(),
            ActivityResultCallback<Map<String?, Boolean?>> { perebinha ->


                if (perebinha[Manifest.permission.CALL_PHONE] != null) {
                    wb = perebinha[Manifest.permission.CALL_PHONE]!!
                }

            }

        )


        Buscar()
        Resposta()
        Botoes()

    }

    fun Buscar() {
        Btvoltar = findViewById(R.id.Btvoltar)
        Btwpp = findViewById(R.id.Btwpp)
        Btcamisetas = findViewById(R.id.Btcamisetas)
        Bttenis22 = findViewById(R.id.Bttenis22)
        Btmoletom = findViewById(R.id.Btmoletom)
        Bttenis = findViewById(R.id.Bttenis)

    }
    fun Botoes(){
        Btvoltar.setOnClickListener(){
            startActivity(Intent(baseContext, MainActivity::class.java))
        }
        Btcamisetas.setOnClickListener() {
            startActivity(Intent(baseContext, Tela_camisetas::class.java))


        }
        Btmoletom.setOnClickListener() {
            startActivity(Intent(baseContext, Tela_moletom::class.java))


        }
        Bttenis.setOnClickListener() {
            startActivity(Intent(baseContext, Tela_tenis::class.java))


        }
        Bttenis22.setOnClickListener() {
            startActivity(Intent(baseContext, Tela_tenis::class.java))


        }
        Btwpp.setOnClickListener() {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://api.whatsapp.com/send?phone=5551994236189&text=Bem%20vindo%20a%20loja%20mec4you")
                )
            )

        }

    }

    fun Resposta(){


        wb = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        val resposta: MutableList<String> = ArrayList()

        if (!wb) {
            resposta.add(Manifest.permission.CALL_PHONE)
        }
        if (!resposta.isEmpty()) {
            carregar!!.launch(resposta.toTypedArray())
        }
    }

}